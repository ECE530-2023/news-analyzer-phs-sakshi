""" Module to display information to user"""
def print_string(string):
    """ outputs the string to console"""
    print(string)
