The application is built using Python and can analyze documents in various formats, including PDF, Microsoft Word,
and plain text files. The application can identify entities, relationships, keywords and sentiments in the text,
and it can generate reports summarizing the information in the document.



Checkout the documentation for more details.
